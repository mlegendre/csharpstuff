﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsForm
{
    class TipClass
    {
        //gets the Bill Amount and Tip Percentages to set it to work in this class        
        public double BillAmount { get; set; }
        public double TipPercentage { get; set; }

        //method to calculate the tip. BillAmount times TipPercentage
        public double CalculateTip
        {
            get
            {
                return BillAmount * TipPercentage;
            }
        }
    }
}
