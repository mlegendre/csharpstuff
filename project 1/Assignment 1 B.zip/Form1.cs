﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForm
{
    public partial class Form1 : Form
    {

        //percentage constants in decimal form
        const double TEN = .1;
        const double TWENTY = .2;
        const double FIFTEEN = .15;
        
        TipClass tip = new TipClass();
        string message;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            tip.BillAmount = Convert.ToDouble(txtDinnerAmount.Text);

            //submit calculation
            if (rBTN20.Checked)
            {
                tip.TipPercentage = TWENTY;
                message = "\nAll right, that's more like it. Want to go to Vegas and get married?";
            }
            else if (rBTN15.Checked)
            {
                tip.TipPercentage = TWENTY;
                message = "\nThat's a little better, but I still don't like you";
            }
            else if (rBTN10.Checked)
            {
                tip.TipPercentage = TEN;
                message = "\nYou sure are cheap. Don't you know serving basturds like you is a\n\t\t\t SHITTY JOB?!?!\nBesides, can't you do something as simple as 10% of anything in your head?\nI guess you have a brain the size of a pinhead...";
            }
            else if (rBTNOther.Checked)
            {
                tip.TipPercentage = Convert.ToInt16(txtOther.Text);
            }

           //answer
            txtTipAns.Text = string.Format("{0:C}", (tip.CalculateTip));            


            //Call the SetVisibility
            SetVisibility(true);
        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            //end the application
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            rBTN10.Checked = false;
            rBTN15.Checked = false;
            rBTN20.Checked = false;
            rBTNOther.Checked = false;
            txtDinnerAmount.Clear();
            txtOther.Clear();

            SetVisibility(false);
        }

        private void SetVisibility(bool showResults)
        {
            //shows the results when a selection is made
            if (showResults)
            {
                txtTipAns.Visible = true;
                lblTipAmount.Visible = true;
                lblHappyTipping.Visible = true;

                txtTipAns.ReadOnly = true;
            }
            //otherwise, it doesn't show anything
            else
            {
                txtTipAns.Visible = false;
                lblTipAmount.Visible = false;
                lblHappyTipping.Visible = false;
            }
         }

    }
}
