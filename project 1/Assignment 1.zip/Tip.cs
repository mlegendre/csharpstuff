﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TippingApplicationConsole

{
    class Tip
    {
            

        public double BillAmount { get; set; }
        public double TipPercentage { get; set; }
        public double CalculateTip
        {
            get
            {
      
                return BillAmount * TipPercentage;
            }
        }
    }
}


