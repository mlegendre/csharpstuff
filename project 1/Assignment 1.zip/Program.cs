﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TippingApplicationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //constants for tip %'s 
            const double TEN = .1; 
             const double TWENTY = .2;
             const double FIFTEEN = .15;

            Tip tip = new Tip();//instantiated object from the Tip class

            string title = "\t**********Tipping Application**********";
            string totalBillString = "\n\nPlease input total bill Amount: $";
            string tipPercentageString ="\n\nPress 1 to tip 10%\nPress 2 to tip 15%\nPress 3 to tip 20%\n";

            displayOutput(title); //Title 
            
            //loop to re-ask for valid input
            //no neg bill amt
            do
            {
                displayOutput(totalBillString);//Ask for bill amt
                tip.BillAmount = Convert.ToDouble(Console.ReadLine());//user input of bill amt

                if (!(tip.BillAmount >= 0)) 
                    displayOutput("Please enter a valid input");

            } while (tip.BillAmount < 0);

            displayOutput(tipPercentageString); //Ask user to choose which Tip % w/ options 1,2 & 3



           //auto response after tip selected
            ConsoleKeyInfo key = new ConsoleKeyInfo();
            key = Console.ReadKey(true);
            string message = ""; //messages shown depending on amt of tip

            //switch stmt to set tip %'s
            switch(key.KeyChar.ToString())
            {
                    
                case "1":
                    tip.TipPercentage = TEN;
                        message = "\nCheap Tipper";
                        break;
                case "2":
                    tip.TipPercentage = FIFTEEN;
                        message = "\nCome on give 5% more!!";
                    break;

                case "3":
                    tip.TipPercentage = TWENTY;
                    message = "\nWoW your LOADED!!";
                    break;
            }

            displayOutput("\nYour tip amuont should be: " + tip.CalculateTip.ToString("C")); //calcalate tip
            Console.WriteLine("\n" + message);//message from switch stmt depending on % amt
            Console.WriteLine("\n\nPress any key to continue . . .");
            Console.Read();
        }

        public static void displayOutput(string str)
        {
            Console.Write(str);
        }
                 
        
    }
}
