﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assignment8
{
    public partial class Form1 : Form
    {

        DataClasses1DataContext context = new DataClasses1DataContext();
        tblContact contact = new tblContact();

        public Form1()
        {
            InitializeComponent();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                contact.name = txtName.Text;
                contact.email = txtEmail.Text;
                contact.phone = txtPhone.Text;
                contact.birthday = Convert.ToDateTime(txtBirth.Text);

                context.tblContacts.InsertOnSubmit(contact);
                context.SubmitChanges();
            }
            catch (Exception)
            {
                lbl.Visible = true;
                lbl.Text = "Please use 2010-10-10 Date Format";
            }


            txtName.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtBirth.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
