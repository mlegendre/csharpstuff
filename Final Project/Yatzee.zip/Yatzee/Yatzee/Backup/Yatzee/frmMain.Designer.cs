namespace Yatzee
{
    partial class frmYatzee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMain = new System.Windows.Forms.Panel();
            this.btnRoll = new System.Windows.Forms.Button();
            this.die5check = new System.Windows.Forms.CheckBox();
            this.die4check = new System.Windows.Forms.CheckBox();
            this.die3check = new System.Windows.Forms.CheckBox();
            this.die2check = new System.Windows.Forms.CheckBox();
            this.die1check = new System.Windows.Forms.CheckBox();
            this.picDie1 = new System.Windows.Forms.PictureBox();
            this.picDie2 = new System.Windows.Forms.PictureBox();
            this.picDie3 = new System.Windows.Forms.PictureBox();
            this.picDie4 = new System.Windows.Forms.PictureBox();
            this.picDie5 = new System.Windows.Forms.PictureBox();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDie1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie5)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.Controls.Add(this.btnRoll);
            this.pnlMain.Controls.Add(this.die5check);
            this.pnlMain.Controls.Add(this.die4check);
            this.pnlMain.Controls.Add(this.die3check);
            this.pnlMain.Controls.Add(this.die2check);
            this.pnlMain.Controls.Add(this.die1check);
            this.pnlMain.Controls.Add(this.picDie1);
            this.pnlMain.Controls.Add(this.picDie2);
            this.pnlMain.Controls.Add(this.picDie3);
            this.pnlMain.Controls.Add(this.picDie4);
            this.pnlMain.Controls.Add(this.picDie5);
            this.pnlMain.Location = new System.Drawing.Point(12, 12);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(645, 538);
            this.pnlMain.TabIndex = 0;
            // 
            // btnRoll
            // 
            this.btnRoll.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll.Location = new System.Drawing.Point(239, 4);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(75, 70);
            this.btnRoll.TabIndex = 10;
            this.btnRoll.Text = "Roll";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // die5check
            // 
            this.die5check.AutoSize = true;
            this.die5check.Location = new System.Drawing.Point(606, 60);
            this.die5check.Name = "die5check";
            this.die5check.Size = new System.Drawing.Size(15, 14);
            this.die5check.TabIndex = 9;
            this.die5check.UseVisualStyleBackColor = true;
            // 
            // die4check
            // 
            this.die4check.AutoSize = true;
            this.die4check.Location = new System.Drawing.Point(548, 60);
            this.die4check.Name = "die4check";
            this.die4check.Size = new System.Drawing.Size(15, 14);
            this.die4check.TabIndex = 8;
            this.die4check.UseVisualStyleBackColor = true;
            // 
            // die3check
            // 
            this.die3check.AutoSize = true;
            this.die3check.Location = new System.Drawing.Point(492, 60);
            this.die3check.Name = "die3check";
            this.die3check.Size = new System.Drawing.Size(15, 14);
            this.die3check.TabIndex = 7;
            this.die3check.UseVisualStyleBackColor = true;
            // 
            // die2check
            // 
            this.die2check.AutoSize = true;
            this.die2check.Location = new System.Drawing.Point(436, 60);
            this.die2check.Name = "die2check";
            this.die2check.Size = new System.Drawing.Size(15, 14);
            this.die2check.TabIndex = 6;
            this.die2check.UseVisualStyleBackColor = true;
            // 
            // die1check
            // 
            this.die1check.AutoSize = true;
            this.die1check.Location = new System.Drawing.Point(375, 60);
            this.die1check.Name = "die1check";
            this.die1check.Size = new System.Drawing.Size(15, 14);
            this.die1check.TabIndex = 5;
            this.die1check.UseVisualStyleBackColor = true;
            // 
            // picDie1
            // 
            this.picDie1.Location = new System.Drawing.Point(358, 4);
            this.picDie1.Name = "picDie1";
            this.picDie1.Size = new System.Drawing.Size(52, 50);
            this.picDie1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDie1.TabIndex = 4;
            this.picDie1.TabStop = false;
            // 
            // picDie2
            // 
            this.picDie2.Location = new System.Drawing.Point(416, 4);
            this.picDie2.Name = "picDie2";
            this.picDie2.Size = new System.Drawing.Size(52, 50);
            this.picDie2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDie2.TabIndex = 3;
            this.picDie2.TabStop = false;
            // 
            // picDie3
            // 
            this.picDie3.Location = new System.Drawing.Point(474, 4);
            this.picDie3.Name = "picDie3";
            this.picDie3.Size = new System.Drawing.Size(52, 50);
            this.picDie3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDie3.TabIndex = 2;
            this.picDie3.TabStop = false;
            // 
            // picDie4
            // 
            this.picDie4.Location = new System.Drawing.Point(532, 4);
            this.picDie4.Name = "picDie4";
            this.picDie4.Size = new System.Drawing.Size(52, 50);
            this.picDie4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDie4.TabIndex = 1;
            this.picDie4.TabStop = false;
            // 
            // picDie5
            // 
            this.picDie5.Location = new System.Drawing.Point(590, 4);
            this.picDie5.Name = "picDie5";
            this.picDie5.Size = new System.Drawing.Size(52, 50);
            this.picDie5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDie5.TabIndex = 0;
            this.picDie5.TabStop = false;
            // 
            // frmYatzee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 562);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmYatzee";
            this.Text = "Yahtzee";
            this.pnlMain.ResumeLayout(false);
            this.pnlMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDie1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDie5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.CheckBox die5check;
        private System.Windows.Forms.CheckBox die4check;
        private System.Windows.Forms.CheckBox die3check;
        private System.Windows.Forms.CheckBox die2check;
        private System.Windows.Forms.CheckBox die1check;
        private System.Windows.Forms.PictureBox picDie1 = new System.Windows.Forms.PictureBox();
        private System.Windows.Forms.PictureBox picDie2 = new System.Windows.Forms.PictureBox();
        private System.Windows.Forms.PictureBox picDie3 = new System.Windows.Forms.PictureBox();
        private System.Windows.Forms.PictureBox picDie4 = new System.Windows.Forms.PictureBox();
        private System.Windows.Forms.PictureBox picDie5 = new System.Windows.Forms.PictureBox();

    }
}

